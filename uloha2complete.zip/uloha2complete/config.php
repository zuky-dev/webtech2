<?php
$server = "localhost";
$username = "Sisa";
$password = "9frfgw2powN";
$db = "uloha2";
?>